<div class="field">
  <h3><?php echo $label ?></h3>
  <div class="findingAidLink">
    <a href="<?php echo public_path($path) ?>" target="_blank"><?php echo $filename ?></a>
  </div>
</div>
