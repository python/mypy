<h1><?php echo $levelOfDescriptionAndIdentifier ?><?php if (!empty($levelOfDescriptionAndIdentifier)): ?> - <?php endif; ?><?php echo render_title($title) ?></h1>
