<button class="<?php echo $class ?>"
  data-clipboard-url="<?php echo $url ?>"
  data-clipboard-slug="<?php echo $slug ?>"
  <?php echo $tooltip ? 'data-toggle="tooltip"' : '' ?>
  data-title="<?php echo $title ?>"
  data-alt-title="<?php echo $altTitle ?>">
  <?php echo $title ?>
</button>
