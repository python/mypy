<script type="text/javascript" charset="utf-8" src="/js/privacyMessage.js"></script>

<div class="animateNicely" id="privacy-message">

    <div class="alert alert-info">
        <button type="button" class="c-btn c-btn-submit c-btn-right-align privacy-message-button">Ok</button>
      <div id="privacy-message-content">
        <?php echo render_value_inline($notificationMessage) ?>
      </div>
    </div>

</div>
